﻿// Supported with union (c) 2018-2021 Union team

#ifndef __ZINC_DIALOGS_H__VER3__
#define __ZINC_DIALOGS_H__VER3__

#include "zIncViews.h"
#include "zViewDialog.h"
#include "zViewDialogChoice.h"
#include "zInput_Win32.h"

namespace Gothic_II_Addon {

} // namespace Gothic_II_Addon

#endif // __ZINC_DIALOGS_H__VER3__